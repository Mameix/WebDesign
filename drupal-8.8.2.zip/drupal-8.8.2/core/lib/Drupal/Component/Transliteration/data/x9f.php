<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'cu', 'qu', 'chao', 'wa', 'zhu', 'zhi', 'meng', 'ao', 'bie', 'tuo', 'bi', 'yuan', 'chao', 'tuo', 'ding', 'mi',
  0x10 => 'nai', 'ding', 'zi', 'gu', 'gu', 'dong', 'fen', 'tao', 'yuan', 'pi', 'chang', 'gao', 'qi', 'yuan', 'tang', 'teng',
  0x20 => 'shu', 'shu', 'fen', 'fei', 'wen', 'ba', 'diao', 'tuo', 'zhong', 'qu', 'sheng', 'shi', 'you', 'shi', 'ting', 'wu',
  0x30 => 'nian', 'jing', 'hun', 'ju', 'yan', 'tu', 'si', 'xi', 'xian', 'yan', 'lei', 'bi', 'yao', 'qiu', 'han', 'wu',
  0x40 => 'wu', 'hou', 'xie', 'e', 'zha', 'xiu', 'weng', 'zha', 'nong', 'nang', 'qi', 'zhai', 'ji', 'zi', 'ji', 'ji',
  0x50 => 'qi', 'ji', 'chi', 'chen', 'chen', 'he', 'ya', 'yin', 'xie', 'bao', 'ze', 'xie', 'chai', 'chi', 'yan', 'ju',
  0x60 => 'tiao', 'ling', 'ling', 'chu', 'quan', 'xie', 'ken', 'nie', 'jiu', 'yao', 'chuo', 'kun', 'yu', 'chu', 'yi', 'ni',
  0x70 => 'ze', 'zou', 'qu', 'yun', 'yan', 'ou', 'e', 'wo', 'yi', 'ci', 'zou', 'dian', 'chu', 'jin', 'ya', 'chi',
  0x80 => 'chen', 'he', 'yin', 'ju', 'ling', 'bao', 'tiao', 'zi', 'ken', 'yu', 'chuo', 'qu', 'wo', 'long', 'pang', 'gong',
  0x90 => 'pang', 'yan', 'long', 'long', 'gong', 'kan', 'da', 'ling', 'da', 'long', 'gong', 'kan', 'gui', 'qiu', 'bie', 'gui',
  0xA0 => 'yue', 'chui', 'he', 'jue', 'xie', 'yu', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0xB0 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0xC0 => NULL, NULL, NULL, 'shan', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0xD0 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0xE0 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0xF0 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
];
